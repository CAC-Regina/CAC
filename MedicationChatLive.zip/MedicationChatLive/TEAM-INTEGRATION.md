# Combining this chatbot with your team's app

## Keep the feature separate

- `android/app/src/main/java/com/example/medicationchat/MainActivity.java`: self-contained chat screen.
- `LiveSession.java` in the same package: pairing, network requests, in-memory conversation state and background work.
- `backend/bot.mjs`: AI scope, safety boundaries, answer generation and review.
- `backend/label-references.mjs`: product-label retrieval for side effects and known interactions.
- `backend/emulator-server.mjs`: local emulator transport and pairing, separate from AI behavior.

The chatbot does not change your team's medication records, schedules, navigation or database. You can connect those later through explicit backend APIs.

## Add the screen to an existing Java or Kotlin Android app

1. Copy the two Java files into the matching `com/example/medicationchat` source package in the combined app. Java classes can be called from Kotlin.
2. Add an activity entry to your team's manifest using the fully qualified name `com.example.medicationchat.MainActivity`, a no-action-bar theme, `android:exported="false"`, and `android:windowSoftInputMode="adjustResize"`. Do not copy its MAIN/LAUNCHER intent filter; keep your team's existing home screen.
3. Open the screen from a button or navigation destination:

```java
startActivity(new android.content.Intent(this, com.example.medicationchat.MainActivity.class));
```

```kotlin
startActivity(android.content.Intent(this, com.example.medicationchat.MainActivity::class.java))
```

4. Merge `INTERNET` and, for target API 37+, `ACCESS_LOCAL_NETWORK` permissions. The screen requests local access before pairing.
5. Merge the debug network-security rule for `10.0.2.2` with any existing network-security configuration instead of replacing the team's configuration.
6. Keep your team's application ID, launcher activity, dependencies and Gradle structure. Match the required compile SDK 37.2 configuration in this sample if adopting its target 37 setup.

## Backend contract

For local emulator development:

- `POST /pair`: JSON `{ "code": "123456" }` → `{ "token": "..." }`.
- `POST /chat`: bearer token plus `{ "message": "...", "history": [{"role":"user", "content":"..."}] }`.
- Reply: `{ "kind": "medical", "answer": "...", "sources": [{ "id":"...", "title":"...", "url":"..." }] }`.

History is limited to 10 entries; each message to 3000 characters. The UI currently limits typed messages to 500 characters. HTTP 401 requires pairing again; 429 asks the user to wait; 503 means live AI is unavailable.

For the combined production app, replace `/pair` with your team's normal user login/token verification. Put the backend behind HTTPS and change the client endpoint. The current local pairing service must remain bound to loopback and must not be published as a public API. Never put the OpenAI key in the APK or source control.

## Evidence and testing

The API uses live model calls, but scope checks and medical answers are not guaranteed accurate. Label retrieval cannot confirm every interaction or account for the user's health history. Add clinician-reviewed evaluations and a maintained interaction data source before patient use. Automated tests currently mock the AI responses; they validate wiring and boundaries rather than clinical accuracy.
