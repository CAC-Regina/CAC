@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 22 or newer, then run this file again.
  pause
  exit /b 1
)
if not exist .env (
  copy .env.example .env >nul
  echo Created .env. Open it in Notepad, add your OpenAI API key, save, then run this file again.
  pause
  exit /b 1
)
node --env-file=.env emulator-server.mjs
pause
