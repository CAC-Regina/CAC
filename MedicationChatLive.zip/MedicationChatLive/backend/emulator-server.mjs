import http from 'node:http';
import { randomInt, randomBytes, timingSafeEqual } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { createBot, createModel, validateRequest } from './bot.mjs';

export function createEmulatorServer({ bot, code, now = Date.now }) {
  const sessions = new Map();
  let windowStart = now(), pairs = 0, chats = 0, active = 0;
  const equals = (a, b) => {
    const x = Buffer.from(a), y = Buffer.from(b);
    return x.length === y.length && timingSafeEqual(x, y);
  };
  const server = http.createServer(async (req, res) => {
    const send = (status, body) => {
      if (res.destroyed) return;
      res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify(body));
    };
    // Local emulator development only. No web origins or public network listener.
    if (req.headers.origin) return send(403, { error: 'Browser calls are disabled.' });
    if (req.method === 'GET' && req.url === '/health') return send(200, { ok: true });
    if (req.method !== 'POST' || !['/pair', '/chat'].includes(req.url)) return send(404, { error: 'Not found.' });
    if (req.headers['content-type']?.split(';')[0].trim() !== 'application/json') return send(415, { error: 'Use application/json.' });
    if (now() - windowStart >= 60000) { windowStart = now(); pairs = 0; chats = 0; }
    for (const [token, expires] of sessions) if (expires <= now()) sessions.delete(token);
    if (req.url === '/pair' && ++pairs > 5) return send(429, { error: 'Too many pairing attempts. Wait one minute.' });
    if (req.url === '/chat') {
      const token = (req.headers.authorization ?? '').replace(/^Bearer /, '');
      if (!sessions.has(token)) return send(401, { error: 'Tap Connect and enter the current pairing code.' });
      if (++chats > 20 || active >= 2) return send(429, { error: 'Please wait a moment before sending another message.' });
    }
    let data;
    try {
      const chunks = []; let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 48000) return send(413, { error: 'Message is too large.' });
        chunks.push(chunk);
      }
      data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch { return send(400, { error: 'Invalid JSON.' }); }
    if (req.url === '/pair') {
      if (typeof data?.code !== 'string' || !equals(data.code, code)) return send(401, { error: 'Incorrect pairing code.' });
      if (sessions.size >= 10) return send(429, { error: 'Restart the server to reset paired sessions.' });
      const token = randomBytes(32).toString('hex');
      sessions.set(token, now() + 12 * 60 * 60 * 1000);
      return send(200, { token });
    }
    try { data = validateRequest(data); }
    catch { return send(400, { error: 'Send 1–3000 characters and up to 10 history messages.' }); }
    active++;
    try {
      const result = await bot(data);
      send(result.kind === 'unavailable' ? 503 : 200, result);
    } catch { send(503, { error: 'AI unavailable. Check the server configuration.' }); }
    finally { active--; }
  });
  server.requestTimeout = 10000;
  server.headersTimeout = 10000;
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const key = process.env.OPENAI_API_KEY;
  if (!key || key.startsWith('replace-')) {
    console.error('Open backend/.env and enter your OpenAI API key. Then restart this server.');
    process.exitCode = 1;
  } else {
    const code = String(randomInt(100000, 1000000));
    const bot = createBot(createModel({ apiKey: key, model: process.env.OPENAI_MODEL || 'gpt-6-astra' }));
    createEmulatorServer({ bot, code }).listen(Number(process.env.PORT || 3000), '127.0.0.1', () => {
      console.log(`Server ready. In Medication Chat Live tap Connect and enter: ${code}`);
      console.log('Keep this window open. Pairing lasts until restart or 12 hours. API requests may incur charges.');
    });
  }
}
