# Medication Chat Live — Android Studio + API 37.2

This version calls live AI through a local Node.js backend. It has no offline chatbot fallback. The API key stays on your computer, never inside the APK.

## 1. Set up the live server once

1. Install Node.js 22 or newer if it is not installed.
2. In the `backend` folder, copy `.env.example` and rename the copy `.env` (not `.env.txt`).
3. Open `.env` in Notepad and replace `replace-with-your-openai-api-key` with your own OpenAI API key. Save. Keep the key private; do not paste it into chat or Android code.
4. Leave `OPENAI_MODEL=gpt-6-astra`, or set a Responses structured-output model available in your API account.
5. Double-click `backend/start-server.bat`. Keep its window open. It displays a six-digit pairing code.

The API account needs access to the chosen model and available billing/credits. Live calls may incur charges. The server's startup message confirms it is listening, not that your API credentials have been accepted; the first chat request checks the provider connection.

## 2. Open the new Android project

1. In Android Studio choose **File → Open**.
2. Select the **android** folder inside **MedicationChatLive**, containing `settings.gradle`. Do not create a new project.
3. In **Tools → SDK Manager**, install **Android SDK Platform 37.2** (enable **Show Package Details** if needed), plus **Build-Tools 36.0.0**.
4. Let Gradle sync. Use Android Studio's bundled JDK (17 or newer).
5. Select **app**, choose your emulator, and click **Run ▶**.

The project uses Android Gradle Plugin 9.4.0, Gradle 9.6.0, `compileSdk` major 37 + minor 2, and `targetSdk` 37. The minor compile API is configured separately from the integer target API. Minimum Android is API 26. It does not require 37.2-only runtime functions, so it also runs on your existing API 37.0 emulator.

## 3. Connect and chat

1. Open **Medication Chat Live** in the emulator. It installs separately from the old offline app.
2. Tap **Connect**, allow local network access if Android asks, and enter the six-digit code from the server window.
3. Ask “What is ibuprofen used for?” or try an off-topic question.

The app uses `http://10.0.2.2:3000`, the standard Android emulator address for your computer. The server listens only on `127.0.0.1`. Keep the port at 3000 unless you change both client and server. This setup is for the local Android emulator, not a physical phone or public deployment.

## What changed

- Replaced the Java preset-answer engine with asynchronous backend requests.
- Sends the last ten conversation messages for follow-ups.
- Shows connection/loading/error states, uses timeouts, and retains an in-flight request across rotation.
- Handles system bars and keyboard insets for newer Android versions.
- Pairs with a temporary in-memory session token; no AI keys or shared server secrets are embedded in the app.
- Debug builds allow HTTP only to the emulator host. Release builds do not allow this HTTP connection and need a production HTTPS backend.

## Medication scope

Live AI classifies questions, generates answers from server-provided references, and checks generated medical answers against those references. Off-topic questions, dose/treatment decisions and potential emergencies use fixed boundary responses. Models may still misclassify a request or generate an incorrect answer.

The backend retrieves product-specific drug-label excerpts from **openFDA** for up to four named medicines and links the corresponding **DailyMed** labels. It includes side-effect and interaction sections when available, with short MedlinePlus fallback references for acetaminophen and ibuprofen. Retrieval is limited to matching single-ingredient products, and coverage is not guaranteed. Labels can differ by formulation and route, and excerpts can be truncated. Missing interaction information never means a combination is safe. This is not a comprehensive interaction checker or a clinically validated product. It does not log doses or schedule reminders.

## Troubleshooting

- **Cannot reach server:** keep `start-server.bat` running; check that port 3000 is free and you are using the standard Android emulator.
- **Incorrect code / reconnect required:** use the current code after each server restart. Sessions expire after 12 hours and are not saved after the app process closes.
- **AI unavailable:** check the API key, account billing, chosen model access and internet connection. The app never substitutes an offline answer on network failure.
- **SDK missing:** install platform **37.2** via SDK Manager and sync again.
- **Unsupported plugin:** update Android Studio to a version supporting AGP 9.4.0.
- **Busy / rate limit:** wait a minute. The local server limits pairing attempts and chat traffic.

For production, replace local pairing with user authentication and authorization, serve HTTPS, add appropriate privacy/consent controls, and use maintained clinically reviewed reference material. Requests and history are sent to OpenAI; `store: false` is not a guarantee of zero provider retention. This server does not log chat text.

## Tests and documentation

Verified: compiled against API 37.2, installed and launched on the running Pixel 9 emulator, and passed 22 backend checks. Live openFDA retrieval was checked for warfarin and metformin. A paid OpenAI response has not been tested because no API key was provided. See `TEAM-INTEGRATION.md` for merging the feature with your team's app.

Run `npm test` inside `backend` for deterministic tests without API charges. Mock tests validate control flow and failure handling, not real-model accuracy.

- [OpenAI structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [Android minor SDK build settings](https://developer.android.com/build)
- [openFDA drug label API](https://open.fda.gov/apis/drug/label/how-to-use-the-endpoint/)
- [Medication reference: acetaminophen](https://medlineplus.gov/druginfo/meds/a681004.html)
- [Medication reference: ibuprofen](https://medlineplus.gov/druginfo/meds/a682159.html)
