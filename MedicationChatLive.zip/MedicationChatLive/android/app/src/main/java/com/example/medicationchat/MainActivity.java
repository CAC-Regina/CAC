package com.example.medicationchat;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.util.Linkify;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import java.util.ArrayList;

public final class MainActivity extends Activity {
    private LiveSession session;
    private TextView status;
    private Button connect;
    private Button send;
    private LinearLayout conversation;
    private ScrollView scroll;
    private EditText input;
    private final int teal = Color.rgb(18, 104, 94);
    private final int ink = Color.rgb(28, 47, 49);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        session = (LiveSession) getLastNonConfigurationInstance();
        if (session == null) session = new LiveSession();
        getWindow().setStatusBarColor(teal);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244, 248, 247));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
                android.graphics.Insets keyboard = insets.getInsets(android.view.WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, keyboard.bottom));
                return insets;
            });
        }

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(18), dp(20), dp(16));
        header.setBackgroundColor(teal);
        TextView title = text("Medication Chat Live", 24, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title);
        TextView subtitle = text("LIVE AI  •  Medication questions", 12, Color.rgb(203, 235, 225));
        subtitle.setPadding(0, dp(8), 0, 0);
        header.addView(subtitle);
        root.addView(header);

        TextView notice = text("AI can make mistakes. Ask a pharmacist before changing medication.", 12, ink);
        notice.setPadding(dp(20), dp(10), dp(20), dp(10));
        root.addView(notice);
        LinearLayout connection = new LinearLayout(this);
        connection.setPadding(dp(16), 0, dp(12), 0);
        connection.setGravity(Gravity.CENTER_VERTICAL);
        status = text(session.status, 12, teal);
        connection.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        connect = new Button(this); connect.setText("Connect"); connect.setAllCaps(false);
        connect.setOnClickListener(v -> showPairing());
        connection.addView(connect); root.addView(connection);
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        conversation = new LinearLayout(this);
        conversation.setOrientation(LinearLayout.VERTICAL);
        conversation.setPadding(dp(14), dp(8), dp(14), dp(8));
        scroll.addView(conversation);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        HorizontalScrollView samples = new HorizontalScrollView(this);
        samples.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(dp(10), 0, dp(10), 0);
        String[] questions = {"What side effects can ibuprofen cause?", "What interactions are known between ibuprofen and warfarin?", "What is the weather?"};
        String[] labels = {"Side effects", "Interactions", "Try off-topic"};
        for (int n = 0; n < questions.length; n++) {
            final String question = questions[n];
            Button chip = new Button(this);
            chip.setText(labels[n]); chip.setAllCaps(false); chip.setTextColor(teal);
            chip.setOnClickListener(v -> submit(question));
            chips.addView(chip);
        }
        samples.addView(chips);
        root.addView(samples);

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(12), dp(8), dp(12), dp(12));
        composer.setBackgroundColor(Color.WHITE);
        input = new EditText(this);
        input.setId(1001);
        input.setHint("Ask about medication...");
        input.setTextSize(16); input.setTextColor(ink);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setSingleLine(true);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(500)});
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        input.setBackground(bubble(Color.rgb(241, 246, 245)));
        composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        send = new Button(this);
        send.setText("Send"); send.setAllCaps(false); send.setTextColor(teal);
        send.setOnClickListener(v -> submit(input.getText().toString()));
        composer.addView(send);
        input.setOnEditorActionListener((v, action, event) -> {
            if (action == EditorInfo.IME_ACTION_SEND) { submit(input.getText().toString()); return true; }
            return false;
        });
        root.addView(composer);

        session.onChange = this::refresh;
        refresh();
    }

    private void submit(String raw) {
        String question = raw.trim();
        if (question.isEmpty() || session.busy) return;
        if (!hasLocalAccess()) { showPairing(); return; }
        if (session.token.isEmpty()) { showPairing(); return; }
        input.setText("");
        session.send(question);
    }

    private void addMessage(String message, boolean user) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(bubble(user ? teal : Color.WHITE));
        TextView label = text(user ? "YOU" : "MEDICATION ASSISTANT", 10, user ? Color.rgb(206, 236, 230) : teal);
        label.setTypeface(null, Typeface.BOLD);
        card.addView(label);
        TextView body = text(message, 16, user ? Color.WHITE : ink);
        body.setPadding(0, dp(6), 0, 0);
        body.setTextIsSelectable(true);
        if (!user) { Linkify.addLinks(body, Linkify.WEB_URLS); body.setLinkTextColor(teal); }
        card.addView(body);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(user ? dp(36) : 0, 0, user ? 0 : dp(24), dp(12));
        conversation.addView(card, params);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void refresh() {
        conversation.removeAllViews();
        for (int n = 0; n < session.messages.size(); n++) addMessage(session.messages.get(n), session.roles.get(n) == 1);
        status.setText(session.status);
        send.setEnabled(!session.busy && !session.token.isEmpty());
        connect.setEnabled(!session.busy);
        input.setEnabled(!session.busy);
    }
    private void showPairing() {
        if (session.busy) return;
        if (!hasLocalAccess()) {
            requestPermissions(new String[]{"android.permission.ACCESS_LOCAL_NETWORK"}, 37);
            return;
        }
        EditText code = new EditText(this);
        code.setHint("6-digit pairing code");
        code.setInputType(InputType.TYPE_CLASS_NUMBER);
        code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        new AlertDialog.Builder(this).setTitle("Connect to live AI")
            .setMessage("Start the server on your computer and enter its code. Your questions will be sent to OpenAI.")
            .setView(code).setNegativeButton("Cancel", null)
            .setPositiveButton("Connect", (dialog, which) -> {
                String value = code.getText().toString().trim();
                if (value.length() == 6) session.pair(value);
                else Toast.makeText(this, "Enter all 6 digits.", Toast.LENGTH_SHORT).show();
            }).show();
    }
    private boolean hasLocalAccess() {
        return Build.VERSION.SDK_INT < 37 || checkSelfPermission("android.permission.ACCESS_LOCAL_NETWORK") == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 37) {
            if (hasLocalAccess()) showPairing();
            else new AlertDialog.Builder(this).setTitle("Local connection needed")
                .setMessage("Allow local network access in this app's permissions to connect to the server on your computer.")
                .setPositiveButton("OK", null).show();
        }
    }
    @Override public Object onRetainNonConfigurationInstance() { return session; }
    @Override protected void onDestroy() {
        session.onChange = null;
        if (!isChangingConfigurations()) session.close();
        super.onDestroy();
    }
    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); return v;
    }
    private GradientDrawable bubble(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(16)); return d;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
