package com.example.medicationchat;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

/** Retained across rotation. Tokens and chat history stay in memory only. */
final class LiveSession {
    final ArrayList<String> messages = new ArrayList<>();
    final ArrayList<Integer> roles = new ArrayList<>(); // 0 assistant, 1 user, 2 connection status
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    Runnable onChange;
    boolean busy = false;
    String token = "";
    String status = "Not connected";
    private static final String BASE = "http://10.0.2.2:3000";

    LiveSession() {
        add("Welcome! Tap Connect and enter the code shown by the server on your computer. Medication questions are sent to OpenAI. Do not enter names or other identifying details.", 2);
    }
    private void changed() { if (onChange != null) onChange.run(); }
    private void add(String message, int role) {
        if (messages.size() >= 60) { messages.remove(0); roles.remove(0); }
        messages.add(message); roles.add(role);
    }
    void pair(String code) {
        if (busy) return;
        busy = true; status = "Connecting..."; changed();
        worker.execute(() -> {
            try {
                JSONObject payload = new JSONObject().put("code", code);
                String newToken = request("/pair", payload, "").getString("token");
                main.post(() -> { token = newToken; busy = false; status = "Connected · Live AI"; add("Connected. Ask about side effects or name medicines to discuss known interactions. Answers use available label information; ask a pharmacist before making treatment decisions.", 2); changed(); });
            } catch (Exception e) {
                String message = friendly(e);
                main.post(() -> { busy = false; status = "Connection failed"; add(message, 2); changed(); });
            }
        });
    }
    void send(String question) {
        if (busy || token.isEmpty() || question.trim().isEmpty()) return;
        final JSONObject payload = new JSONObject();
        try {
            JSONArray history = new JSONArray();
            ArrayList<Integer> eligible = new ArrayList<>();
            for (int n = 0; n < roles.size(); n++) if (roles.get(n) != 2) eligible.add(n);
            for (int n = Math.max(0, eligible.size() - 10); n < eligible.size(); n++) {
                int index = eligible.get(n);
                String content = messages.get(index);
                history.put(new JSONObject().put("role", roles.get(index) == 1 ? "user" : "assistant")
                    .put("content", content.substring(0, Math.min(3000, content.length()))));
            }
            payload.put("message", question).put("history", history);
        } catch (Exception e) { add("Could not prepare the message.", 2); changed(); return; }
        add(question, 1); busy = true; status = "Checking medication information..."; changed();
        final String auth = token;
        worker.execute(() -> {
            try {
                JSONObject result = request("/chat", payload, auth);
                StringBuilder answer = new StringBuilder(result.getString("answer"));
                JSONArray sources = result.optJSONArray("sources");
                if (sources != null) for (int n = 0; n < sources.length(); n++) {
                    JSONObject source = sources.getJSONObject(n);
                    answer.append("\n\n").append(source.getString("title")).append("\n").append(source.getString("url"));
                }
                main.post(() -> { busy = false; status = "Connected · Live AI"; add(answer.toString(), 0); changed(); });
            } catch (Exception e) {
                String message = friendly(e);
                boolean expired = e instanceof ServiceError && ((ServiceError)e).code == 401;
                main.post(() -> { busy = false; if (expired) token = ""; status = expired ? "Reconnect required" : "Request failed"; add(message, 2); changed(); });
            }
        });
    }
    private JSONObject request(String path, JSONObject payload, String auth) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(BASE + path).openConnection();
        try {
            connection.setRequestMethod("POST"); connection.setConnectTimeout(10000); connection.setReadTimeout(120000);
            connection.setInstanceFollowRedirects(false); connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            if (!auth.isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + auth);
            byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (java.io.OutputStream output = connection.getOutputStream()) { output.write(bytes); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            if (stream == null) throw new ServiceError(code, "Server returned an empty response.");
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try (InputStream in = stream) {
                byte[] chunk = new byte[4096]; int count;
                while ((count = in.read(chunk)) != -1) {
                    if (buffer.size() + count > 64000) throw new Exception("Response too large");
                    buffer.write(chunk, 0, count);
                }
            }
            JSONObject result = new JSONObject(buffer.toString("UTF-8"));
            if (code < 200 || code >= 300) throw new ServiceError(code, result.optString("answer", result.optString("error", "Server error.")));
            return result;
        } finally { connection.disconnect(); }
    }
    private String friendly(Exception e) {
        if (e instanceof ServiceError) return e.getMessage();
        return "Could not reach the live server. Keep start-server.bat running on your computer and check your connection. Then try again. No offline answer was substituted.";
    }
    void close() { onChange = null; worker.shutdownNow(); }
    private static final class ServiceError extends Exception {
        final int code;
        ServiceError(int code, String message) { super(message); this.code = code; }
    }
}
