# Medication Chat Local — Android Studio

Real local AI using Ollama and qwen3:4b. No API key or per-message API bill. Your computer supplies the processing. This is a development prototype, not a clinically validated medication service.

## Windows setup

1. Extract this entire ZIP to a folder.
2. Install Node.js LTS from https://nodejs.org if needed (version 22 or newer). Keep installer defaults.
3. Install Ollama from https://ollama.com/download/windows and open it. Keep its default local server settings.
4. Open this project's backend folder and double-click **setup-model.bat**. Wait for the roughly 2.5 GB model download. This download is needed only once.
5. Close the old paid chatbot server window if running. Double-click **start-server.bat**. Keep this window and Ollama open. It displays a six-digit code.
6. In Android Studio select **Open**, then select this project's **android** folder. Do not create a new project. Let Gradle sync finish and accept installation of missing SDK components. The project uses API **37.2**, Gradle 9.6.0 and Android Gradle Plugin 9.4.0.
7. Select the **app** run configuration and your emulator, then press Run.
8. Open **Medication Chat Local**, tap **Connect**, allow local network access if asked, and enter the code from step 5.
9. Try a medication side-effect or interaction question. The first answer may take several minutes. Weather questions should receive a medication-topic redirect.

No npm install, .env file, API key or billing setup is needed. Later runs need Ollama, start-server.bat and the Android app.

Alternatively, drag the supplied **MedicationChatFree.apk** onto your running emulator to install the app without building it. Still complete steps 2–5 and 8–9.

## How it works and limitations

Android Emulator connects to Node on port 3000, which connects to Ollama on port 11434. AI processes the conversation on your computer. Extracted medication names are sent to the free public openFDA label service over the internet; full chats are not sent to a hosted AI service. Avoid personal identifiers. This app keeps conversations and pairing tokens in memory.

The model gives short conversational answers and asks for missing medicine names. General medication education may use model knowledge without supporting excerpts. Such answers are not verified against current sources. Source links appear only for answers based on supplied references. Automated AI review can still miss mistakes. Automated review and topic filtering can still fail. Label matching and excerpts are limited; missing warnings never establish that a combination is safe. This is not a comprehensive interaction checker. Ask a pharmacist before making treatment decisions.

## Troubleshooting

- **Port 3000 busy:** close the old chatbot server window, then restart this server.
- **Ollama not reachable:** open Ollama and restart start-server.bat.
- **Model missing:** run setup-model.bat and let it finish.
- **Slow or out of memory:** close heavy programs. Each AI step has a three-minute timeout; a medication answer may use three steps. Speed depends on hardware and available memory.
- **Cannot connect:** keep the server open, enter its latest code, and allow local network access. The emulator must be on the same computer as the server.
- **Insufficient references:** ask a pharmacist; suitable public label information may be missing.
- **Conversation too long:** close and reopen the app, reconnect, and ask about one or two medicines at a time.

Each teammate can follow these steps on their own computer. Model weights are downloaded separately. Physical phones and public deployment require a different server setup.

Backend checks: run npm test in the backend folder. Tests simulate AI responses and do not validate clinical accuracy or prove local inference performance.

## Updating from the first free version

Close your old server window. Extract this ZIP and run backend/start-server.bat from the NEW folder. Reconnect your existing Medication Chat Local app with the new code. No Android reinstall or model download is needed. This update changes the backend.

## Version 3: pair-specific sources

Interaction questions now look up the exact two-drug combination on Patient.info, trying both name orders and validating the page title. When a page explicitly reports no known interaction, the app attributes that published finding and includes a personal-safety caveat. It never infers this from a missing warning or a missing page. Other pair summaries are explained by the local model with a source link. Missing pages fall back to the existing drug-label lookup.

The app sends extracted medicine names to Patient.info as well as openFDA. These are public website requests, not hosted AI requests. A page can be unavailable or change layout; retrieval then fails closed. This is a limited educational lookup, not a comprehensive licensed interaction database. It does not handle every brand, formulation, drug combination or multi-drug interaction.

Update: close the old server window, extract this ZIP, and run backend/start-server.bat from this newly extracted folder. Reconnect the existing Android app using the new code. No model download or Android reinstall is needed.

Validation: 34 automated tests passed. Real local-model tests covered the exact ibuprofen/amoxicillin question, warfarin/ibuprofen, an unnamed antibiotic, a follow-up naming amoxicillin, and weather. These checks establish observed behavior for those prompts, not clinical validation or guaranteed correctness for all prompts.

## Version 4: interaction-button regression

The AI reviewer now receives only the current question, resolved medicine names and selected evidence. When it rejects a generated pair summary, a short complete sentence (at most 25 words) from the exact-pair source can be displayed with attribution instead. Rejected AI text is not shown. Missing sources still cannot establish safety. Tested the exact interaction-button wording in a new conversation and after amoxicillin discussion.

Close the old server, extract this ZIP and start its backend/start-server.bat. The console must show **Medication Chat backend v4**. Reconnect using its new code. The existing Android app works without reinstalling.
