// Public educational pages, not an exhaustive interaction database.
// Only exact, named pairs are accepted; missing pages never mean no interaction.
const normalize = s => s.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const plain = s => s.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
  .replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/&#39;|&apos;/g, "'")
  .replace(/&quot;/g, '"').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();

export function parsePairPage(html, names, url) {
  const title = plain(html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1] ?? '');
  const expected = names.map(normalize);
  const allowed = [expected, [...expected].reverse()].map(pair => `can i take ${pair[0]} and ${pair[1]} together`);
  if (!allowed.includes(normalize(title))) return null;
  // Read only the page's introductory pair summary, excluding navigation and related articles.
  const intro = html.match(/data-testid="introduction"[^>]*>([\s\S]*?)<\/p>/i)?.[1];
  if (!intro || !/<p\b/i.test(intro)) return null;
  const summary = plain(intro.slice(intro.indexOf('<p')));
  if (!summary || summary.length > 1600 || !expected.every(name => normalize(summary).includes(name))) return null;
  return {
    id: `pair-${expected.join('-')}`, title: `Patient.info: ${names.join(' + ')}`,
    url, pair: names, summary, text: `Exact-pair educational summary from Patient.info: ${summary}\nThis is general published information, not a personalized safety decision or a complete interaction screen.`
  };
}

export async function loadPairReference(names, { fetchImpl = fetch } = {}) {
  if (!Array.isArray(names) || names.length !== 2 || names.some(n => typeof n !== 'string' || !/^[a-zA-Z][a-zA-Z -]{1,59}$/.test(n))) return [];
  const clean = names.map(normalize);
  if (clean[0] === clean[1]) return [];
  for (const pair of [clean, [...clean].reverse()]) {
    const slug = pair.map(n => n.replace(/ /g, '-')).join('-and-');
    const url = `https://patient.info/medication-interactions/${slug}-interaction`;
    try {
      const response = await fetchImpl(url, { signal: AbortSignal.timeout(8000), redirect: 'error' });
      if (!response.ok) continue;
      if (Number(response.headers?.get('content-length') ?? 0) > 1000000) continue;
      let html = '';
      for await (const chunk of response.body) {
        html += Buffer.from(chunk).toString('utf8');
        if (html.length > 1000000) throw new Error('Page too large');
      }
      const ref = parsePairPage(html, clean, url);
      if (ref) return [ref];
    } catch { /* Missing, changed or unavailable source: no claim about interaction status. */ }
  }
  return [];
}

export function explicitNoInteraction(ref) {
  if (!ref?.pair || ref.pair.length !== 2 || typeof ref.summary !== 'string') return false;
  const text = normalize(ref.summary.split(/[.!?]/)[0]);
  const [a, b] = ref.pair.map(normalize);
  return [
    `there is no known harmful interaction between ${a} and ${b}`,
    `there is no known harmful interaction between ${b} and ${a}`,
    `there is no known interaction between ${a} and ${b}`,
    `there is no known interaction between ${b} and ${a}`
  ].includes(text);
}

// When a model cannot reliably summarize, relay a short complete source sentence.
// Never truncate a sentence: doing so could drop a negation or qualification.
export function pairExcerpt(ref) {
  if (!ref?.summary || !Array.isArray(ref.pair) || ref.pair.length !== 2) return null;
  const sentence = ref.summary.match(/^[^.!?]+[.!?](?=\s|$)/)?.[0];
  if (!sentence || sentence.split(/\s+/).length > 25 || !ref.pair.every(name => normalize(sentence).includes(normalize(name))) ||
      !/\b(interaction|interact|bleeding|risk|increases?|reduces?)\b/i.test(sentence)) return null;
  return `Patient.info: "${sentence}" A pharmacist can check how this applies to your medicines and health conditions.`;
}
