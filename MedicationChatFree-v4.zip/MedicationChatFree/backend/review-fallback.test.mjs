import test from 'node:test';
import assert from 'node:assert/strict';
import { createBot } from './bot.mjs';
import { pairExcerpt } from './pair-references.mjs';
const ref = { id: 'pair-test', pair: ['drugone', 'drugtwo'], title: 'Test source', url: 'https://patient.info/test', summary: 'Drugone and drugtwo increase bleeding risk.', text: 'Drugone and drugtwo increase bleeding risk.' };
test('review rejection relays exact source sentence, never rejected AI text', async () => {
  const bot = createBot(async (stage, instructions, data) => {
    if (stage === 'route') return { route: 'medical', interaction: true, medications: ref.pair };
    if (stage === 'answer') return { supported: true, basis: 'references', source_ids: [ref.id], answer: 'Rejected model content.' };
    assert.equal(data.history, undefined);
    return { approved: false };
  }, { loadPair: async () => [ref] });
  const result = await bot({ message: 'What interactions are known between drugone and drugtwo?', history: [{ role: 'assistant', content: 'Unrelated earlier advice' }] });
  assert.match(result.answer, /Drugone and drugtwo increase bleeding risk/);
  assert.doesNotMatch(result.answer, /Rejected model/);
  assert.equal(result.sources[0].url, ref.url);
});
test('source excerpt requires a short complete sentence naming both medicines', () => {
  assert.equal(pairExcerpt({ ...ref, summary: 'Drugone increases risk.' }), null);
  assert.equal(pairExcerpt({ ...ref, summary: 'Drugone and drugtwo increase risk' }), null);
  assert.equal(pairExcerpt({ ...ref, summary: 'Drugone and drugtwo increase risk ' + 'word '.repeat(26) + '.' }), null);
  assert.equal(pairExcerpt({ ...ref, summary: 'Drugone and drugtwo are names.' }), null);
});
