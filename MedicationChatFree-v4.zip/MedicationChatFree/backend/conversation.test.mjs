import test from 'node:test';
import assert from 'node:assert/strict';
import { createBot } from './bot.mjs';
test('missing antibiotic name asks a follow-up before lookup', async () => {
  const bot = createBot(async () => ({ route: 'medical', interaction: true, medications: ['ibuprofen', 'antibiotics'] }), { loadReferences: async () => { throw new Error('must not fetch'); } });
  assert.match((await bot({ message: 'Ibuprofen with antibiotics?' })).answer, /exact name/);
});
for (const basis of ['general', 'clarification']) test(`${basis} can answer without excerpts after review`, async () => {
  let reviewed = false;
  const history = [{ role: 'user', content: 'Medication question' }];
  const bot = createBot(async (stage, instructions, data) => {
    if (stage !== 'review') assert.deepEqual(data.history, history);
    else assert.equal(data.history, undefined);
    if (stage === 'route') return { route: 'medical' };
    if (stage === 'answer') return { supported: false, basis, answer: 'A short educational response.', source_ids: [] };
    reviewed = true; assert.equal(data.basis, basis); return { approved: true };
  }, { loadReferences: async () => [] });
  assert.equal((await bot({ message: 'Explain please', history })).basis, basis);
  assert.equal(reviewed, true);
});
test('long, unsafe and falsely cited general answers are withheld', async () => {
  for (const candidate of [
    { answer: 'word '.repeat(101), source_ids: [] },
    { answer: 'An unsafe test answer', source_ids: [] },
    { answer: 'A falsely cited test answer', source_ids: ['ibuprofen'] }
  ]) {
    const bot = createBot(async stage => {
      if (stage === 'route') return { route: 'medical' };
      if (stage === 'answer') return { ...candidate, supported: true, basis: 'general' };
      return { approved: false };
    }, { loadReferences: async () => [] });
    assert.equal((await bot({ message: 'Medicine question' })).kind, 'insufficient');
  }
});
