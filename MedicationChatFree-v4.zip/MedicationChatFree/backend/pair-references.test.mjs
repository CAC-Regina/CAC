import test from 'node:test';
import assert from 'node:assert/strict';
import { parsePairPage, loadPairReference, explicitNoInteraction } from './pair-references.mjs';
import { createBot } from './bot.mjs';
const names = ['drugone', 'drugtwo'];
const page = summary => `<h1>Can I take Drugone and Drugtwo together?</h1><div data-testid="introduction"><p>${summary}</p></div>`;
const statement = 'There is no known harmful interaction between drugone and drugtwo.';
const ref = parsePairPage(page(statement), names, 'https://patient.info/medication-interactions/drugone-and-drugtwo-interaction');
test('only exact pair pages and explicit statements establish a published no-known-interaction report', () => {
  assert.ok(explicitNoInteraction(ref));
  assert.equal(parsePairPage(page(statement), ['drugone', 'other'], ref.url), null);
  assert.equal(parsePairPage('<h1>404</h1>', names, ref.url), null);
  for (const summary of ['No information available.', 'It is not true that there is no known harmful interaction between drugone and drugtwo.', 'There is no known harmful interaction between drugone and other.']) {
    assert.equal(explicitNoInteraction({ ...ref, summary }), false);
  }
});
test('lookup tries reverse order and rejects invalid names without fetching', async () => {
  let calls = 0;
  const fetchImpl = async url => {
    assert.equal(new URL(url).hostname, 'patient.info');
    calls++;
    return calls === 1 ? new Response('', { status: 404 }) : new Response(page(statement));
  };
  assert.equal((await loadPairReference(names, { fetchImpl })).length, 1);
  assert.equal(calls, 2);
  assert.deepEqual(await loadPairReference(['../secret', 'drugtwo'], { fetchImpl }), []);
  assert.equal(calls, 2);
});
test('missing source never means the pair has no interaction', async () => {
  assert.deepEqual(await loadPairReference(names, { fetchImpl: async () => new Response('', { status: 404 }) }), []);
});
test('sourced pair report is attributed with personal-safety caveat', async () => {
  const bot = createBot(async () => ({ route: 'medical', interaction: true, medications: names }), { loadPair: async () => [ref] });
  const result = await bot({ message: 'Do these interact?' });
  assert.match(result.answer, /Patient.info reports/);
  assert.match(result.answer, /does not guarantee/);
  assert.equal(result.sources[0].url, ref.url);
});
test('clarification follow-up resolves the previous medicine before pair lookup', async () => {
  let calls = 0;
  const bot = createBot(async () => ++calls === 1
    ? { route: 'medical', interaction: true, medications: ['drugtwo'] }
    : { route: 'medical', interaction: true, medications: ['drugone', 'antibiotics'] },
  { loadPair: async found => { assert.deepEqual(found, names); return [ref]; } });
  const result = await bot({ message: 'Drugtwo', history: [{ role: 'user', content: 'Drugone with antibiotics?' }, { role: 'assistant', content: 'Which antibiotic?' }] });
  assert.equal(result.sources[0].url, ref.url);
});
