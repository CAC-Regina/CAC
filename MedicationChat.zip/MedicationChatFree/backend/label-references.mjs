// Educational retrieval, not a comprehensive drug-interaction checking service.
const normalize = value => String(value).toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const sections = { drug_interactions: 2400, adverse_reactions: 2400, boxed_warning: 1600, warnings_and_cautions: 1600, warnings: 1200, indications_and_usage: 800 };

export async function loadLabelReferences(names, { fetchImpl = fetch } = {}) {
  if (!Array.isArray(names)) return [];
  const drugs = [...new Set(names.filter(name => typeof name === 'string' && /^[a-zA-Z0-9 -]{2,80}$/.test(name)))].slice(0, 4);
  const results = await Promise.all(drugs.map(async name => {
    try {
      const url = new URL('https://api.fda.gov/drug/label.json');
      url.searchParams.set('search', `openfda.generic_name:"${name}" OR openfda.brand_name:"${name}"`);
      url.searchParams.set('limit', '5');
      url.searchParams.set('sort', 'effective_time:desc');
      const response = await fetchImpl(url.toString(), { signal: AbortSignal.timeout(10000) });
      if (!response.ok) return null;
      const data = await response.json();
      const wanted = normalize(name);
      const record = (data.results ?? []).find(label => {
        const generic = label.openfda?.generic_name ?? [];
        if (generic.length !== 1 || /\band\b|;|,|\//i.test(generic[0])) return false;
        const candidates = [...generic, ...(label.openfda?.brand_name ?? [])].map(normalize);
        return candidates.some(value => value === wanted || value === wanted + ' hydrochloride' || value === wanted + ' sodium');
      });
      if (!record || !/^[a-f0-9-]{36}$/i.test(record.set_id ?? '')) return null;
      const text = Object.entries(sections).flatMap(([field, max]) => {
        if (!Array.isArray(record[field])) return [];
        const content = record[field].join(' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
        return [`${field}: ${content.slice(0, max)}${content.length > max ? ' [excerpt truncated]' : ''}`];
      }).join('\n');
      if (!text) return null;
      const generic = record.openfda.generic_name[0];
      const brand = record.openfda.brand_name?.[0] ?? generic;
      return {
        id: `label-${record.set_id}`,
        title: `Drug label: ${brand} (${generic})`,
        url: `https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=${record.set_id}`,
        text: `Product-specific label for ${brand} / ${generic}. Route: ${(record.openfda.route ?? []).join(', ')}. Label date: ${record.effective_time ?? 'unknown'}. Partial excerpts, not a complete interaction check.\n${text}`
      };
    } catch { return null; }
  }));
  return results.filter(Boolean);
}
