// Fallback excerpts. Ibuprofen expanded from MedlinePlus on 2026-09-26.
// These are not complete drug monographs or a clinically reviewed knowledge base.
export const references = [
  {
    id: 'acetaminophen',
    title: 'MedlinePlus: Acetaminophen',
    url: 'https://medlineplus.gov/druginfo/meds/a681004.html',
    text: 'Acetaminophen reduces fever and treats mild to moderate pain. Excess acetaminophen can seriously injure the liver. Multiple products can contain acetaminophen, creating an accidental overdose risk. Follow the product or prescription label. Suspected overdose requires immediate medical help even without symptoms.'
  },
  {
    id: 'ibuprofen',
    title: 'MedlinePlus: Ibuprofen',
    url: 'https://medlineplus.gov/druginfo/meds/a682159.html',
    text: 'Ibuprofen is an NSAID used for pain, fever, and inflammation. Possible side effects include constipation, gas, bloating, dizziness, nervousness, and ringing in the ears. Serious risks include gastrointestinal ulcers or bleeding, heart attack, and stroke. MedlinePlus specifically advises telling a doctor about blood thinners, aspirin, other NSAIDs such as naproxen, oral steroids, SSRIs such as sertraline or fluoxetine, and SNRIs such as duloxetine or venlafaxine. These medicines are listed in its gastrointestinal bleeding warning. This excerpt does not establish safety for an individual or exclude other interactions. Difficulty breathing, chest pain, one-sided weakness or slurred speech requires emergency help.'
  }
];
