@echo off
cd /d "%~dp0"
set "MEDCHAT_OLLAMA=ollama"
where ollama >nul 2>nul
if errorlevel 1 (
  if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" (
    set "MEDCHAT_OLLAMA=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
  ) else (
    echo Install Ollama from https://ollama.com/download/windows and open it first.
    pause
    exit /b 1
  )
)
echo This downloads qwen3:4b, about 2.5 GB. Keep Ollama open.
"%MEDCHAT_OLLAMA%" pull qwen3:4b
if errorlevel 1 (
  echo Download failed. Open Ollama, check internet, then run this file again.
) else (
  echo Model ready. Next, double-click start-server.bat.
)
pause
