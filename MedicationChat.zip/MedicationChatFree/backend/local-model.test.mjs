import test from 'node:test';
import assert from 'node:assert/strict';
import { createModel, checkLocalModel, LocalModelError } from './local-model.mjs';
import { createBot } from './bot.mjs';

test('local adapter fixes destination/model and requests structured non-thinking output', async () => {
  const schema = { type: 'object' };
  const call = createModel({ fetchImpl: async (url, options) => {
    assert.equal(url, 'http://127.0.0.1:11434/api/chat');
    assert.equal(options.redirect, 'error');
    assert.equal(options.headers.Authorization, undefined);
    const body = JSON.parse(options.body);
    assert.equal(body.model, 'qwen3:4b');
    assert.equal(body.think, false);
    assert.equal(body.stream, false);
    assert.deepEqual(body.format, schema);
    assert.equal(body.messages[1].role, 'user');
    return { ok: true, json: async () => ({ done: true, done_reason: 'stop', message: { content: '{"route":"off_topic"}' } }) };
  } });
  assert.deepEqual(await call('route', 'rules', {}, schema), { route: 'off_topic' });
});
test('failed, truncated and malformed local outputs fail closed', async () => {
  for (const response of [ { ok: false, status: 500 }, { ok: false, status: 404 },
    { ok: true, json: async () => ({ done: false }) },
    { ok: true, json: async () => ({ done: true, done_reason: 'length', message: { content: '{}' } }) },
    { ok: true, json: async () => ({ done: true, done_reason: 'stop', message: { content: 'bad' } }) } ]) {
    await assert.rejects(createModel({ fetchImpl: async () => response })('answer', '', {}, {}));
  }
});
test('readiness distinguishes installed and missing model', async () => {
  await checkLocalModel(async () => ({ ok: true, json: async () => ({ models: [{ name: 'qwen3:4b' }] }) }));
  await assert.rejects(checkLocalModel(async () => ({ ok: true, json: async () => ({ models: [] }) })), /setup-model/);
  await assert.rejects(checkLocalModel(async () => { throw new Error('private error'); }), /Open Ollama/);
});
test('oversized context never reaches inference', async () => {
  let called = false;
  await assert.rejects(createModel({ fetchImpl: async () => { called = true; } })('answer', '', { text: 'x'.repeat(24001) }, {}), /too much information/);
  assert.equal(called, false);
});
test('known local failures have actionable safe messages', async () => {
  const bot = createBot(async () => { throw new LocalModelError('Open Ollama on your computer.'); });
  assert.equal((await bot({ message: 'hello' })).answer, 'Open Ollama on your computer.');
});
