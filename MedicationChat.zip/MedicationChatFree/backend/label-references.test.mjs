import test from 'node:test';
import assert from 'node:assert/strict';
import { loadLabelReferences } from './label-references.mjs';
import { createBot } from './bot.mjs';
const label = {
  set_id: '12345678-1234-1234-1234-123456789abc',
  openfda: { generic_name: ['WARFARIN SODIUM'], brand_name: ['WARFARIN SODIUM'], route: ['ORAL'] },
  drug_interactions: ['Test interaction evidence.'], adverse_reactions: ['Test adverse reaction evidence.']
};
test('matches requested drug and returns evidence with server-controlled citation', async () => {
  const refs = await loadLabelReferences(['warfarin'], { fetchImpl: async url => {
    assert.equal(new URL(url).hostname, 'api.fda.gov');
    return { ok: true, json: async () => ({ results: [label] }) };
  } });
  assert.equal(refs.length, 1);
  assert.match(refs[0].text, /drug_interactions/);
  assert.match(refs[0].url, /^https:\/\/dailymed.nlm.nih.gov\//);
});
test('rejects unrelated products, combinations and unavailable labels', async () => {
  for (const record of [{ ...label, openfda: { generic_name: ['UNRELATED'] } },
    { ...label, openfda: { generic_name: ['WARFARIN AND OTHER'] } }, { ...label, set_id: 'fake' }]) {
    assert.deepEqual(await loadLabelReferences(['warfarin'], { fetchImpl: async () => ({ ok: true, json: async () => ({ results: [record] }) }) }), []);
  }
  assert.deepEqual(await loadLabelReferences(['warfarin'], { fetchImpl: async () => { throw new Error('offline'); } }), []);
});
test('rejects search syntax and limits lookups to four medicines', async () => {
  let calls = 0;
  const options = { fetchImpl: async () => { calls++; return { ok: false }; } };
  await loadLabelReferences(['name" OR *', 'http://example.com'], options);
  assert.equal(calls, 0);
  await loadLabelReferences(['one', 'two', 'three', 'four', 'five'], options);
  assert.equal(calls, 4);
});
test('retrieved evidence is passed to generator and reviewer', async () => {
  let count = 0;
  const ref = { id: 'retrieved', title: 'Test label', url: 'https://dailymed.nlm.nih.gov/', text: 'Test evidence' };
  const bot = createBot(async (name, instructions, data) => {
    count++;
    if (name === 'route') return { route: 'medical', medications: ['warfarin'] };
    assert.ok(data.references.some(r => r.id === 'retrieved'));
    if (name === 'answer') return { supported: true, answer: 'Test supported answer.', source_ids: ['retrieved'] };
    return { approved: true };
  }, { loadReferences: async names => { assert.deepEqual(names, ['warfarin']); return [ref]; } });
  const result = await bot({ message: 'What interactions are known with warfarin?' });
  assert.equal(result.kind, 'medical'); assert.equal(result.sources[0].id, 'retrieved'); assert.equal(count, 3);
});
