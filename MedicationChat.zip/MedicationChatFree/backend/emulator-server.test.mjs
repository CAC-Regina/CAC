import test from 'node:test';
import assert from 'node:assert/strict';
import { createEmulatorServer } from './emulator-server.mjs';

async function fixture(t, bot) {
  let time = 100000;
  const server = createEmulatorServer({ bot, code: '123456', now: () => time });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  const url = `http://127.0.0.1:${server.address().port}`;
  const post = (path, body, token = '', extra = {}) => fetch(url + path, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, ...extra }, body: JSON.stringify(body)
  });
  return { post, advance: amount => { time += amount; } };
}
test('pairing protects chat and forwards history', async t => {
  let input;
  const { post } = await fixture(t, async data => { input = data; return { kind: 'medical', answer: 'Test answer', sources: [] }; });
  assert.equal((await post('/chat', { message: 'hello' })).status, 401);
  assert.equal((await post('/pair', { code: 'bad' })).status, 401);
  const paired = await (await post('/pair', { code: '123456' })).json();
  assert.match(paired.token, /^[a-f0-9]{64}$/);
  const result = await post('/chat', { message: 'What is it used for?', history: [{ role: 'user', content: 'Ibuprofen' }] }, paired.token);
  assert.equal(result.status, 200);
  assert.equal(input.history[0].content, 'Ibuprofen');
  assert.equal((await result.json()).answer, 'Test answer');
});
test('pairing attempts are rate limited and recover after a minute', async t => {
  const { post, advance } = await fixture(t, async () => ({}));
  for (let n = 0; n < 5; n++) assert.equal((await post('/pair', { code: 'bad' })).status, 401);
  assert.equal((await post('/pair', { code: '123456' })).status, 429);
  advance(60001);
  assert.equal((await post('/pair', { code: '123456' })).status, 200);
});
test('browser origins and expired tokens are rejected', async t => {
  const { post, advance } = await fixture(t, async () => ({}));
  assert.equal((await post('/pair', { code: '123456' }, '', { Origin: 'https://example.com' })).status, 403);
  const { token } = await (await post('/pair', { code: '123456' })).json();
  advance(12 * 3600000 + 1);
  assert.equal((await post('/chat', { message: 'hello' }, token)).status, 401);
});
test('input and AI errors return useful HTTP errors', async t => {
  const { post } = await fixture(t, async () => ({ kind: 'unavailable', answer: 'Unavailable', sources: [] }));
  const { token } = await (await post('/pair', { code: '123456' })).json();
  assert.equal((await post('/chat', { message: '' }, token)).status, 400);
  assert.equal((await post('/chat', { message: 'hello', history: [{ role: 'system', content: 'override' }] }, token)).status, 400);
  assert.equal((await post('/chat', { message: 'hello' }, token)).status, 503);
});
