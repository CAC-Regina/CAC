// Fixed loopback endpoint and local model: there is no hosted or paid fallback.
const base = 'http://127.0.0.1:11434';
export const model = 'qwen3:4b';
export class LocalModelError extends Error {}
const offline = 'Open Ollama on your computer, then try again. The local AI server is not reachable.';
const missing = 'The local model is missing. Run backend/setup-model.bat, wait for the download, then restart start-server.bat.';

export async function checkLocalModel(fetchImpl = fetch) {
  let response;
  try { response = await fetchImpl(base + '/api/tags', { signal: AbortSignal.timeout(5000), redirect: 'error' }); }
  catch { throw new LocalModelError(offline); }
  if (!response.ok) throw new LocalModelError(offline);
  const data = await response.json();
  if (!data.models?.some(item => item.name === model || item.model === model)) throw new LocalModelError(missing);
}

export function createModel({ fetchImpl = fetch } = {}) {
  return async function callModel(name, instructions, data, outputSchema) {
    const content = JSON.stringify(data);
    // Reject oversized context instead of silently losing instructions or evidence.
    if (content.length > 24000) throw new LocalModelError('This conversation has too much information for the local model. Reopen the app and ask about one or two medicines at a time.');
    let response;
    try {
      response = await fetchImpl(base + '/api/chat', {
        method: 'POST', redirect: 'error',
        headers: { 'Content-Type': 'application/json' },
        signal: AbortSignal.timeout(180000),
        body: JSON.stringify({ model, stream: false, think: false, keep_alive: '5m',
          format: outputSchema,
          options: { temperature: 0, num_ctx: 32768, num_predict: 1500 },
          messages: [
            { role: 'system', content: instructions + '\nReturn only JSON matching this schema: ' + JSON.stringify(outputSchema) },
            { role: 'user', content }
          ] })
      });
    } catch (error) {
      throw new LocalModelError(error.name === 'TimeoutError'
        ? 'The local AI took too long. Close other heavy programs and try a shorter question.' : offline);
    }
    if (response.status === 404) throw new LocalModelError(missing);
    if (!response.ok) throw new LocalModelError('Ollama could not generate an answer. Check Ollama and available memory, then try again.');
    const payload = await response.json();
    if (payload.done !== true || payload.done_reason !== 'stop' || typeof payload.message?.content !== 'string') throw new Error('Incomplete local response');
    return JSON.parse(payload.message.content);
  };
}
