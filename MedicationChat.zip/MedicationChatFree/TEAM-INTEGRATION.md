# Team integration

MainActivity.java provides the native Java screen. LiveSession.java manages requests and temporary history. Both are in android/app/src/main/java/com/example/medicationchat. They do not modify medication records or reminders.

Copy these classes into your app, update package names and rename MainActivity if necessary, then launch the chat Activity from a button. Merge manifest permissions, theme and debug network security configuration. Do not overwrite the whole team project. The demo application ID is com.example.medicationchat.local.

POST /pair with JSON code returns a token. POST /chat uses bearer authentication and JSON message/history. History allows ten user/assistant messages. Results contain kind, answer and sources (id/title/url). Errors may contain error or an unavailable answer. Preserve source links and limitations in your UI.

The emulator address http://10.0.2.2:3000 points to its own host computer. Each teammate needs Node, Ollama, model weights and their own running backend. No shared hosted server is included. Physical phones/public deployment need a separate design. Do not expose this development server or Ollama publicly. Release builds intentionally disallow debug HTTP connections.

Before patient use, clinically validate responses, medication/formulation matching, interaction coverage and failure handling, and review privacy and deployment controls. AI self-review is not clinical validation.
