# Medication Chat — Android Studio project

## Open and run

1. Extract the ZIP.
2. In Android Studio choose **Open**, then select the **MedicationChatAndroid** folder containing `settings.gradle`. Do not open the old Node.js ZIP or only the `app` subfolder.
3. Let Gradle sync finish. Allow Android Studio to download any missing build components. First setup needs internet.
4. Select your Android emulator (Android 8.0 / API 26 or newer).
5. Select **app** beside the device selector, then click the green **Run ▶** button.

The app opens directly to a chat screen. No Node.js server, API key, account, or internet connection is needed while chatting. Tap a sample question or type a message and press Send.

## What this version does

- Native Java Android app with message bubbles, Send button, and example questions.
- Preset English replies about basic acetaminophen and ibuprofen uses and risks, with source links.
- Redirects unrelated questions, and includes cautious replies for selected dose and emergency phrases.
- Simple follow-up support: ask about ibuprofen, then “What are its side effects?”
- Preserves recent messages during screen rotation. No permanent chat storage.

**This is an offline simulation, not live AI.** It uses phrase matching and cannot understand every wording or reliably detect emergencies. It is for demonstrating the chatbot screen and basic behavior, not patient use. It does not log doses, schedule reminders, diagnose conditions, or calculate doses. Other medications and questions outside its small reference set receive a fallback reply.

The original Node.js project is separate and unchanged. Restoring live AI would require connecting this app through an authenticated backend; this Android demo does not call it and contains no API keys.

## Build requirements

Use an Android Studio version supporting Android Gradle Plugin 9.4.0. The project includes a Gradle 9.6.0 wrapper and uses Android SDK 34, Build Tools 36.0.0, and Java 17 source compatibility. Use Android Studio's bundled Gradle JDK (17 or newer).

If sync says the SDK is missing, open **Tools → SDK Manager**, install **Android 14 / API 34** and **Android SDK Build-Tools 36.0.0**, then sync again. If it says the plugin is unsupported, update Android Studio. If Java 8 is selected, choose the bundled JDK under **Settings → Build, Execution, Deployment → Build Tools → Gradle**.

Build tool compatibility: https://developer.android.com/build/releases/agp-9-4-0-release-notes

## Main files

- `app/src/main/java/com/example/medicationchat/MainActivity.java`: chat screen.
- `app/src/main/java/com/example/medicationchat/DemoBot.java`: preset reply logic.
- `app/src/main/AndroidManifest.xml`: app entry point.

## Medication references

The short educational replies reuse the original starter's reference summaries. They are incomplete and not independently clinically reviewed:

- https://medlineplus.gov/druginfo/meds/a681004.html
- https://medlineplus.gov/druginfo/meds/a682159.html

## Verification

The debug APK compiled successfully with the installed Android tools. Thirteen standalone Java checks passed for the preset reply logic. No emulator was running during verification, so the visual interface has not been tested on an emulator.

