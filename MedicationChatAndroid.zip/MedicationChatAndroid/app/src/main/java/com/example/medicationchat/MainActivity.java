package com.example.medicationchat;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.util.Linkify;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import java.util.ArrayList;

public final class MainActivity extends Activity {
    private final DemoBot bot = new DemoBot();
    private final ArrayList<String> messages = new ArrayList<>();
    private final ArrayList<Integer> roles = new ArrayList<>();
    private LinearLayout conversation;
    private ScrollView scroll;
    private EditText input;
    private final int teal = Color.rgb(18, 104, 94);
    private final int ink = Color.rgb(28, 47, 49);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(teal);
        getWindow().setNavigationBarColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244, 248, 247));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(18), dp(20), dp(16));
        header.setBackgroundColor(teal);
        TextView title = text("Medication Chat", 24, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title);
        TextView subtitle = text("OFFLINE DEMO  •  Preset replies", 12, Color.rgb(203, 235, 225));
        subtitle.setPadding(0, dp(8), 0, 0);
        header.addView(subtitle);
        root.addView(header);

        TextView notice = text("For a class demo, not personal medical advice.", 12, ink);
        notice.setPadding(dp(20), dp(10), dp(20), dp(10));
        root.addView(notice);
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        conversation = new LinearLayout(this);
        conversation.setOrientation(LinearLayout.VERTICAL);
        conversation.setPadding(dp(14), dp(8), dp(14), dp(8));
        scroll.addView(conversation);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        HorizontalScrollView samples = new HorizontalScrollView(this);
        samples.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setPadding(dp(10), 0, dp(10), 0);
        String[] questions = {"What is acetaminophen used for?", "What is ibuprofen used for?", "What is the weather?"};
        String[] labels = {"Acetaminophen", "Ibuprofen", "Try off-topic"};
        for (int n = 0; n < questions.length; n++) {
            final String question = questions[n];
            Button chip = new Button(this);
            chip.setText(labels[n]); chip.setAllCaps(false); chip.setTextColor(teal);
            chip.setOnClickListener(v -> submit(question));
            chips.addView(chip);
        }
        samples.addView(chips);
        root.addView(samples);

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(12), dp(8), dp(12), dp(12));
        composer.setBackgroundColor(Color.WHITE);
        input = new EditText(this);
        input.setId(1001);
        input.setHint("Ask about medication...");
        input.setTextSize(16); input.setTextColor(ink);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setSingleLine(true);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(500)});
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        input.setBackground(bubble(Color.rgb(241, 246, 245)));
        composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        Button send = new Button(this);
        send.setText("Send"); send.setAllCaps(false); send.setTextColor(teal);
        send.setOnClickListener(v -> submit(input.getText().toString()));
        composer.addView(send);
        input.setOnEditorActionListener((v, action, event) -> {
            if (action == EditorInfo.IME_ACTION_SEND) { submit(input.getText().toString()); return true; }
            return false;
        });
        root.addView(composer);

        if (state != null) {
            ArrayList<String> savedMessages = state.getStringArrayList("messages");
            ArrayList<Integer> savedRoles = state.getIntegerArrayList("roles");
            if (savedMessages != null && savedRoles != null && savedMessages.size() == savedRoles.size()) {
                for (int n = 0; n < savedMessages.size(); n++) addMessage(savedMessages.get(n), savedRoles.get(n) == 1);
            }
            bot.restoreMedicine(state.getString("medicine", ""));
        }
        if (messages.isEmpty()) addMessage(DemoBot.WELCOME, false);
    }

    private void submit(String raw) {
        String question = raw.trim();
        if (question.isEmpty()) return;
        input.setText("");
        addMessage(question, true);
        addMessage(bot.reply(question), false);
    }

    private void addMessage(String message, boolean user) {
        // Bound saved state so long demo sessions do not exceed Android's bundle limit.
        if (messages.size() >= 60) {
            messages.remove(0); roles.remove(0); conversation.removeViewAt(0);
        }
        messages.add(message); roles.add(user ? 1 : 0);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(bubble(user ? teal : Color.WHITE));
        TextView label = text(user ? "YOU" : "MEDICATION ASSISTANT", 10, user ? Color.rgb(206, 236, 230) : teal);
        label.setTypeface(null, Typeface.BOLD);
        card.addView(label);
        TextView body = text(message, 16, user ? Color.WHITE : ink);
        body.setPadding(0, dp(6), 0, 0);
        body.setTextIsSelectable(true);
        if (!user) { Linkify.addLinks(body, Linkify.WEB_URLS); body.setLinkTextColor(teal); }
        card.addView(body);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(user ? dp(36) : 0, 0, user ? 0 : dp(24), dp(12));
        conversation.addView(card, params);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        out.putStringArrayList("messages", messages);
        out.putIntegerArrayList("roles", roles);
        out.putString("medicine", bot.getLastMedicine());
        super.onSaveInstanceState(out);
    }
    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color); return v;
    }
    private GradientDrawable bubble(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(16)); return d;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
