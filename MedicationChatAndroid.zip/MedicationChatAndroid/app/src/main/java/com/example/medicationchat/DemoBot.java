package com.example.medicationchat;

import java.util.Locale;
import java.util.regex.Pattern;

/** Deterministic English-language demonstration. This is not an AI or a triage system. */
public final class DemoBot {
    public static final String WELCOME = "Hi! Try asking what acetaminophen or ibuprofen is used for. This offline demo uses preset replies, not live AI.";
    public static final String OFF_TOPIC = "I can help with medication questions and medication tracking. Please ask me about those topics.";
    public static final String UNKNOWN = "This demo does not have enough information to answer that question. Ask a pharmacist or clinician, or try one of the sample questions.";
    public static final String CLINICIAN = "For dose changes, missed doses, interactions, or advice specific to you, ask your pharmacist or prescribing clinician. This demo cannot decide what is safe for you.";
    public static final String EMERGENCY = "If this may be an overdose or poisoning, contact poison control or urgent medical help now, even without symptoms. For trouble breathing, collapse, a seizure, or someone who cannot be awakened, call your local emergency number. Do not wait for this chat.";
    private String lastMedicine = "";

    private static boolean has(String text, String regex) {
        return Pattern.compile("\\b(?:" + regex + ")\\b").matcher(text).find();
    }

    public String reply(String raw) {
        String q = raw.toLowerCase(Locale.ROOT).replace('\u2019', '\'').trim();
        if (q.isEmpty()) return "Type a medication question to begin.";
        // Conservative demo phrase matching; it cannot reliably recognize emergencies.
        if (has(q, "overdos\\w*|poison\\w*|too many pills|too much (medicine|medication|acetaminophen|ibuprofen)|can't breathe|cannot breathe|trouble breathing|seizure|collapsed|won't wake|cannot wake|can't wake|kill myself|hurt myself|end my life")) return EMERGENCY;
        if (has(q, "weather|forecast|sports|football|movie|joke|politics|recipe|write code|ignore.*rules")) return OFF_TOPIC;
        if (q.matches("(hi|hello|hey|thanks|thank you)[!. ]*")) return WELCOME;
        if (has(q, "dose|dosage|doses|missed|double|pregnan\\w*|child\\w*|baby|breastfeed\\w*|interact\\w*|together|combine|can i take|should i|stop taking|start taking|safe for me|how much")) return CLINICIAN;
        if (has(q, "remind\\w*|track\\w*|log|schedule|did i take|record")) {
            return "A medication tracker can help organize your medication list and dose history. This chat demo cannot save a dose or set reminders yet.";
        }
        boolean a = has(q, "acetaminophen|paracetamol");
        boolean i = has(q, "ibuprofen");
        if (a && i) return CLINICIAN;
        String medicine = a ? "acetaminophen" : i ? "ibuprofen" : "";
        if (!medicine.isEmpty()) lastMedicine = medicine;
        else if (has(q, "it|its|that medicine") && has(q, "used|use|side effects|warning\\w*|risk\\w*")) medicine = lastMedicine;
        if (!medicine.isEmpty()) {
            boolean risks = has(q, "side effects|warning\\w*|risk\\w*");
            boolean uses = has(q, "used|use|what is|what does") || q.equals(medicine);
            if (!risks && !uses) return UNKNOWN;
            if (medicine.equals("acetaminophen")) {
                return (risks
                    ? "Too much acetaminophen can seriously harm the liver. More than one medicine can contain it, so check product labels. This is not a complete list of risks."
                    : "Acetaminophen is used to relieve mild to moderate pain and reduce fever.")
                    + "\n\nSource: https://medlineplus.gov/druginfo/meds/a681004.html";
            }
            return (risks
                ? "Ibuprofen can cause stomach or intestinal ulcers and bleeding. NSAIDs such as ibuprofen can also increase heart attack or stroke risk. This is not a complete list of risks."
                : "Ibuprofen is an NSAID (nonsteroidal anti-inflammatory drug). It is used for pain, fever, and inflammation.")
                + "\n\nSource: https://medlineplus.gov/druginfo/meds/a682159.html";
        }
        if (has(q, "medicine|medication|tablet|pill|drug|side effect|metformin|insulin|antibiotic")) return UNKNOWN;
        return OFF_TOPIC;
    }

    public String getLastMedicine() { return lastMedicine; }
    public void restoreMedicine(String medicine) {
        lastMedicine = "acetaminophen".equals(medicine) || "ibuprofen".equals(medicine) ? medicine : "";
    }
}
